<table border=0 cellpadding=0 cellspacing=0 valign='top'><tr>
<td><a href='https://www.getmangos.eu' target='getmangos.eu'><img src='https://www.getmangos.eu/!assets_mangos/logo.png' border=0></a></td>
<td valign='top'>
<a href='https://www.getmangos.eu/forums/' target='getmangos.forum'><img src='/icons/FORUM.gif' border=0></a>
<a href='https://www.getmangos.eu/wiki' target='getmangos.wiki'><img src='/icons/WIKI.gif' border=0></a>
<a href='https://www.getmangos.eu/github-activity/' target='getmangos.activity'><img src='/icons/ACTIVITY.gif' border=0></a>
<a href='https://www.getmangos.eu/bug-tracker/mangos-two/' target='getmangos.tracker'><img src='/icons/TRACKER.gif' border=0></a>
<br />Build Status: <br/>Linux 
<a href='https://travis-ci.org/mangostwo/server/builds' target='MangosTwo'><img src='https://travis-ci.org/mangostwo/server.png' border=0></a>
 Windows 
<a href='https://ci.appveyor.com/project/MaNGOS/server-80qcn/history' target='MangosTwo'><img src='https://ci.appveyor.com/api/projects/status/github/mangostwo/server?branch=master&svg=true' border=0></a>
</td></tr></table>

WoTLK World Database
===

### A World Database for WoTLK Wow
----
A content database for [**WoTLK**][10] MaNGOS Servers, and [**World of Warcraft**][50] Client Patch
3.3.5a - [Wrath of the Lich King][51].

### How to Install
---------------
##### Linux

1. Run: **InstallDatabases.sh** and follow the onscreen prompts.

##### Windows

1. Run: **InstallDatabases.bat** and follow the onscreen prompts.


[10]: https://github.com/mangostwo/server "mangos Two"

[50]: http://blizzard.com/games/wow/ "World of Warcraft"
[51]: http://www.wowpedia.org/Patch_3.3.5a "WoW 3.3.5a"
